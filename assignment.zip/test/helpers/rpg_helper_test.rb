require 'test_helper'

class RpgHelperTest < ActionView::TestCase
end
